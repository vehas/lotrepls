package org.jruby.util.unsafe;

public interface Unsafe {
    public void throwException(Throwable t);
}
