import sys
assert "/from_SyspathAppendingInitializer_with_love" in sys.path
