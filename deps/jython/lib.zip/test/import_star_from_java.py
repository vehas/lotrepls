from java.util.regex import *

p = Pattern.compile("foo")
assert p.flags() == 0
